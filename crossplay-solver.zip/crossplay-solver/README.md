# Crossplay Solver

Finds the highest-scoring legal moves for NYT Crossplay. This is the engine
stage of the project: you type in the board and rack, it ranks every legal
play. Screenshot parsing and a phone-friendly upload page come next.

## Quick start

```bash
python3 solve.py --rack "EEB?JIH"                      # first move, empty board
python3 solve.py --rack "OSHEART" --board boards/mygame.txt --top 15
```

Requires Python 3.9+. No dependencies.

## Game data

Tile values, tile counts (100 total), the 40-point sweep bonus, and the full
bonus-square layout live in `crossplay.py`. The layout was mapped square by
square from a screenshot of an empty board: 3L on the corners, 3W at D1/L1
and their mirrors, 2W at D8/L8/H4/H12, with everything symmetric under
rotation and transposition (20 3L, 20 2L, 8 3W, 8 2W).

One assumption is unverified: the center square shows the NYT logo and no
multiplier label, so the engine treats it as a plain square. Check it by
playing any first move and comparing the app's score to the solver's
prediction. If the app reports double, set `CENTER_DOUBLES_WORD = True` in
`crossplay.py`.

## Dictionary

Crossplay uses NASPA NWL2023 minus trademarks and proper nouns. NASPA
licenses that list and it is not freely redistributable, so this project
ships with ENABLE (public domain, ~168k playable words). The overlap is
large but not perfect. Two plain-text files patch the gap:

- `extras.txt`: words the app accepts that ENABLE lacks. Seeded with a few
  known NWL additions (HIJAB, EMOJI, SELFIE, ...). Add a word here whenever
  the app accepts something the solver missed.
- `blacklist.txt`: words the app rejected. Add a word here whenever a
  suggested play bounces.

If you obtain a licensed NWL2023 text file, drop it in `words/` and pass
`--dict words/nwl2023.txt`. The extras file then becomes unnecessary.

## Board file format

15 lines of 15 characters. `.` for empty, `A`-`Z` for a tile, lowercase
`a`-`z` for a blank tile playing that letter. In the rack string, `?` is a
blank. Move notation: `8D across` = row 8 starting at column D; `H4 down` =
column H starting at row 4. Lowercase letters in output words mark blanks.

## How it works

`crossplay.py` builds a trie from the word list and runs Appel-Jacobson move
generation: find anchor squares, compute per-square cross-checks for
perpendicular words, extend left parts and right parts through the trie, and
score each play with letter/word multipliers plus cross-word scores and the
sweep bonus. Vertical moves reuse the same code on the transposed board.
`validate_move` independently rechecks every word a play forms, and
`solve.py` runs it on the top results as a safety net.

## Files

- `crossplay.py`: game constants, board, dictionary, move generation, scoring
- `solve.py`: command-line interface
- `words/enable1.txt`: base dictionary
- `extras.txt`, `blacklist.txt`: dictionary patches
- `boards/`: example board files

## Roadmap

1. Done: rules data, move engine, scoring, validation.
2. Next: screenshot parsing (board + rack straight from an uploaded image).
3. Then: single-page web app so this runs from a phone photo picker.
