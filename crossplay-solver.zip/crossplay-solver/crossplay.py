"""NYT Crossplay move engine.

Game data (tile values, tile counts, bonus-square layout, sweep bonus) taken
from the official app's help screen and a screenshot of an empty board,
captured 2026-07. Dictionary: the app uses NASPA NWL2023 minus trademarks and
proper nouns. NWL2023 is licensed by NASPA and not freely redistributable, so
this project ships with ENABLE (public domain, ~173k words), which overlaps
heavily. Use --exclude to blacklist words the app rejects, or drop a licensed
NWL2023 text file into words/ and point --dict at it.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path

N = 15
CENTER = (7, 7)  # 0-indexed
RACK_SIZE = 7
SWEEP_BONUS = 40  # all 7 tiles in one turn, added after multipliers

# Unverified: the center square shows the NYT logo and no multiplier label.
# Assumed plain until checked against an in-app first-move score.
CENTER_DOUBLES_WORD = False

TILE_VALUES = {
    '?': 0,
    'A': 1, 'E': 1, 'I': 1, 'N': 1, 'O': 1, 'R': 1, 'S': 1, 'T': 1,
    'D': 2, 'L': 2, 'U': 2,
    'C': 3, 'H': 3, 'M': 3, 'P': 3,
    'B': 4, 'F': 4, 'G': 4, 'Y': 4,
    'W': 5,
    'K': 6, 'V': 6,
    'X': 8,
    'J': 10, 'Q': 10, 'Z': 10,
}

TILE_COUNTS = {
    '?': 3,
    'A': 9, 'E': 12, 'I': 8, 'N': 5, 'O': 8, 'R': 6, 'S': 5, 'T': 6,
    'D': 4, 'L': 4, 'U': 3,
    'C': 2, 'H': 3, 'M': 2, 'P': 2,
    'B': 2, 'F': 2, 'G': 3, 'Y': 2,
    'W': 2, 'K': 1, 'V': 2, 'X': 1,
    'J': 1, 'Q': 1, 'Z': 1,
}
assert sum(TILE_COUNTS.values()) == 100

ALL_LETTERS = frozenset('ABCDEFGHIJKLMNOPQRSTUVWXYZ')


def _build_premiums() -> dict:
    """Bonus squares mapped from the empty-board screenshot (rows 0-7 defined,
    rows 8-14 mirror rows 6-0). The layout is also left-right symmetric and
    transpose-symmetric, which the tests verify."""
    top = {
        (0, 0): 'TL', (0, 3): 'TW', (0, 7): 'DL', (0, 11): 'TW', (0, 14): 'TL',
        (1, 1): 'DW', (1, 6): 'TL', (1, 8): 'TL', (1, 13): 'DW',
        (2, 4): 'DL', (2, 10): 'DL',
        (3, 0): 'TW', (3, 3): 'DL', (3, 7): 'DW', (3, 11): 'DL', (3, 14): 'TW',
        (4, 2): 'DL', (4, 5): 'TL', (4, 9): 'TL', (4, 12): 'DL',
        (5, 4): 'TL', (5, 7): 'DL', (5, 10): 'TL',
        (6, 1): 'TL', (6, 13): 'TL',
        (7, 0): 'DL', (7, 3): 'DW', (7, 5): 'DL', (7, 9): 'DL',
        (7, 11): 'DW', (7, 14): 'DL',
    }
    prem = dict(top)
    for (r, c), v in top.items():
        prem[(14 - r, c)] = v
    return prem


PREMIUMS = _build_premiums()


def square_multipliers(r: int, c: int) -> tuple[int, int]:
    """(letter_multiplier, word_multiplier) for a square, applied only when a
    new tile lands on it."""
    if (r, c) == CENTER:
        return (1, 2) if CENTER_DOUBLES_WORD else (1, 1)
    p = PREMIUMS.get((r, c))
    if p == 'DL':
        return 2, 1
    if p == 'TL':
        return 3, 1
    if p == 'DW':
        return 1, 2
    if p == 'TW':
        return 1, 3
    return 1, 1


# ---------------------------------------------------------------- dictionary

class TrieNode:
    __slots__ = ('children', 'terminal')

    def __init__(self):
        self.children = {}
        self.terminal = False


class Lexicon:
    def __init__(self, words):
        self.words = set(words)
        self.root = TrieNode()
        for w in self.words:
            node = self.root
            for ch in w:
                nxt = node.children.get(ch)
                if nxt is None:
                    nxt = TrieNode()
                    node.children[ch] = nxt
                node = nxt
            node.terminal = True

    @classmethod
    def load(cls, path, exclude_path=None, include_path=None):
        def read_list(p):
            if not p or not Path(p).exists():
                return set()
            out = set()
            for line in Path(p).read_text().splitlines():
                line = line.split('#', 1)[0]
                for token in line.split():
                    w = token.strip().upper()
                    if 2 <= len(w) <= N and w.isalpha():
                        out.add(w)
            return out

        exclude = read_list(exclude_path)
        words = read_list(path) | read_list(include_path)
        return cls(w for w in words if w not in exclude)


# --------------------------------------------------------------------- board

class Board:
    """grid holds '' for empty or an uppercase letter; coordinates of tiles
    that are blanks (score 0) live in self.blanks."""

    def __init__(self):
        self.grid = [['' for _ in range(N)] for _ in range(N)]
        self.blanks: set[tuple[int, int]] = set()

    @classmethod
    def from_text(cls, text: str) -> 'Board':
        b = cls()
        rows = [ln for ln in (line.strip() for line in text.splitlines()) if ln]
        if len(rows) != N:
            raise ValueError(f'expected {N} board rows, got {len(rows)}')
        for r, ln in enumerate(rows):
            cells = ln.split() if ' ' in ln else list(ln)
            if len(cells) != N:
                raise ValueError(f'row {r + 1} has {len(cells)} cells, expected {N}')
            for c, ch in enumerate(cells):
                if ch in '.-_':
                    continue
                if not ch.isalpha():
                    raise ValueError(f'bad cell {ch!r} at row {r + 1}')
                b.grid[r][c] = ch.upper()
                if ch.islower():
                    b.blanks.add((r, c))
        return b

    @classmethod
    def from_file(cls, path) -> 'Board':
        return cls.from_text(Path(path).read_text())

    def is_empty(self) -> bool:
        return not any(cell for row in self.grid for cell in row)

    def place(self, move: 'Move') -> 'Board':
        nb = Board()
        nb.grid = [row[:] for row in self.grid]
        nb.blanks = set(self.blanks)
        for r, c, letter, is_blank in move.placed:
            nb.grid[r][c] = letter
            if is_blank:
                nb.blanks.add((r, c))
        return nb

    def render(self, highlight=frozenset()) -> str:
        head = '     ' + ''.join(f'{chr(ord("A") + i):^3}' for i in range(N))
        out = [head]
        for r in range(N):
            cells = []
            for c in range(N):
                ch = self.grid[r][c]
                if ch:
                    shown = ch.lower() if (r, c) in self.blanks else ch
                    cells.append(f'[{shown}]' if (r, c) in highlight else f' {shown} ')
                else:
                    cells.append(' . ')
            out.append(f'{r + 1:>3}  ' + ''.join(cells))
        return '\n'.join(out)


# --------------------------------------------------------------------- moves

@dataclass(frozen=True)
class Move:
    row: int            # 0-indexed start of the main word
    col: int
    direction: str      # 'H' or 'V'
    word: str           # main word; lowercase letter = blank tile
    placed: tuple       # ((r, c, LETTER, is_blank), ...)
    score: int

    def notation(self) -> str:
        col_letter = chr(ord('A') + self.col)
        if self.direction == 'H':
            return f'{self.row + 1}{col_letter}'
        return f'{col_letter}{self.row + 1}'

    def describe(self) -> str:
        arrow = 'across' if self.direction == 'H' else 'down'
        return f'{self.word} at {self.notation()} ({arrow}) for {self.score}'


def generate_moves(board: Board, rack: str, lex: Lexicon) -> list[Move]:
    """All legal moves for `rack` on `board`, best first. Rack format:
    letters plus '?' per blank, e.g. 'EEB?JIH'."""
    rack_counter = Counter(rack.upper().replace(' ', ''))
    for t in rack_counter:
        if t != '?' and t not in ALL_LETTERS:
            raise ValueError(f'bad rack tile {t!r}')
    out: dict = {}
    _gen_direction(board.grid, board.blanks, rack_counter, lex, out,
                   transposed=False)
    tgrid = [[board.grid[c][r] for c in range(N)] for r in range(N)]
    tblanks = {(c, r) for (r, c) in board.blanks}
    _gen_direction(tgrid, tblanks, rack_counter, lex, out, transposed=True)
    return sorted(out.values(), key=lambda m: (-m.score, m.word, m.notation()))


def _gen_direction(grid, blanks, rack, lex, out, transposed):
    """Appel-Jacobson generation of across moves in the given orientation.
    Vertical moves come from running this on the transposed grid."""
    root = lex.root
    has_tiles = any(grid[r][c] for r in range(N) for c in range(N))

    anchors = set()
    if not has_tiles:
        anchors.add(CENTER)  # first move must cover the center square
    else:
        for r in range(N):
            for c in range(N):
                if grid[r][c]:
                    continue
                if ((r > 0 and grid[r - 1][c]) or (r < N - 1 and grid[r + 1][c])
                        or (c > 0 and grid[r][c - 1])
                        or (c < N - 1 and grid[r][c + 1])):
                    anchors.add((r, c))

    # Cross-checks: for each empty square with vertical neighbors, the letters
    # that keep the perpendicular word valid, plus that word's base score.
    cross = {}
    for c in range(N):
        for r in range(N):
            if grid[r][c]:
                continue
            if not ((r > 0 and grid[r - 1][c]) or (r < N - 1 and grid[r + 1][c])):
                continue
            rr = r - 1
            pre = []
            while rr >= 0 and grid[rr][c]:
                pre.append(rr)
                rr -= 1
            pre.reverse()
            rr = r + 1
            suf = []
            while rr < N and grid[rr][c]:
                suf.append(rr)
                rr += 1
            pre_s = ''.join(grid[i][c] for i in pre)
            suf_s = ''.join(grid[i][c] for i in suf)
            base = sum(0 if (i, c) in blanks else TILE_VALUES[grid[i][c]]
                       for i in pre + suf)
            allowed = {L for L in ALL_LETTERS
                       if pre_s + L + suf_s in lex.words}
            cross[(r, c)] = (allowed, base, True)

    def cross_at(r, c):
        return cross.get((r, c), (ALL_LETTERS, 0, False))

    def mult(r, c):
        return square_multipliers(c, r) if transposed else square_multipliers(r, c)

    def record(r, start, end_incl, left, right_placed):
        placed_here = [(start + i, L, isb) for i, (L, isb) in enumerate(left)]
        placed_here += right_placed
        if not placed_here:
            return
        pmap = {c: (L, isb) for c, L, isb in placed_here}
        main = 0
        word_mult = 1
        cross_total = 0
        chars = []
        for c in range(start, end_incl + 1):
            if c in pmap:
                L, isb = pmap[c]
                lm, wm = mult(r, c)
                val = 0 if isb else TILE_VALUES[L]
                main += val * lm
                word_mult *= wm
                _, base, has_cross = cross_at(r, c)
                if has_cross:
                    cross_total += (base + val * lm) * wm
                chars.append(L.lower() if isb else L)
            else:
                L = grid[r][c]
                main += 0 if (r, c) in blanks else TILE_VALUES[L]
                chars.append(L.lower() if (r, c) in blanks else L)
        score = main * word_mult + cross_total
        if len(placed_here) == RACK_SIZE:
            score += SWEEP_BONUS
        if transposed:
            placed_real = tuple(sorted((c, r, L, isb) for c, L, isb in placed_here))
            mv = Move(row=start, col=r, direction='V',
                      word=''.join(chars), placed=placed_real, score=score)
        else:
            placed_real = tuple(sorted((r, c, L, isb) for c, L, isb in placed_here))
            mv = Move(row=r, col=start, direction='H',
                      word=''.join(chars), placed=placed_real, score=score)
        key = placed_real  # same physical placement found twice keeps one entry
        prev = out.get(key)
        if prev is None or mv.score > prev.score:
            out[key] = mv

    def extend_right(r, col, node, start, left, right_placed, anchor):
        at_empty = col >= N or not grid[r][col]
        if at_empty:
            if node.terminal and col > anchor and (left or right_placed):
                record(r, start, col - 1, left, right_placed)
            if col >= N:
                return
            allowed, _, _ = cross_at(r, col)
            for L, child in node.children.items():
                if L not in allowed:
                    continue
                if rack[L] > 0:
                    rack[L] -= 1
                    right_placed.append((col, L, False))
                    extend_right(r, col + 1, child, start, left, right_placed, anchor)
                    right_placed.pop()
                    rack[L] += 1
                if rack['?'] > 0:
                    rack['?'] -= 1
                    right_placed.append((col, L, True))
                    extend_right(r, col + 1, child, start, left, right_placed, anchor)
                    right_placed.pop()
                    rack['?'] += 1
        else:
            child = node.children.get(grid[r][col])
            if child is not None:
                extend_right(r, col + 1, child, start, left, right_placed, anchor)

    def left_part(r, node, limit, anchor, left):
        extend_right(r, anchor, node, anchor - len(left), left, [], anchor)
        if limit > 0:
            for L, child in node.children.items():
                if rack[L] > 0:
                    rack[L] -= 1
                    left.append((L, False))
                    left_part(r, child, limit - 1, anchor, left)
                    left.pop()
                    rack[L] += 1
                if rack['?'] > 0:
                    rack['?'] -= 1
                    left.append((L, True))
                    left_part(r, child, limit - 1, anchor, left)
                    left.pop()
                    rack['?'] += 1

    total_tiles = sum(rack.values())
    if total_tiles == 0:
        return
    for r in range(N):
        for c_anchor in sorted(c for (rr, c) in anchors if rr == r):
            if c_anchor > 0 and grid[r][c_anchor - 1]:
                s = c_anchor - 1
                while s >= 0 and grid[r][s]:
                    s -= 1
                s += 1
                node = root
                for cc in range(s, c_anchor):
                    node = node.children.get(grid[r][cc])
                    if node is None:
                        break
                else:
                    extend_right(r, c_anchor, node, s, [], [], c_anchor)
            else:
                k = 0
                cc = c_anchor - 1
                while cc >= 0 and not grid[r][cc] and (r, cc) not in anchors:
                    k += 1
                    cc -= 1
                left_part(r, root, min(k, total_tiles - 1), c_anchor, [])


# ---------------------------------------------------------------- validation

def words_formed(board: Board, move: Move) -> list[str]:
    """Every maximal word of length >= 2 running through a newly placed tile
    after the move is applied. Used to double-check generator output."""
    nb = board.place(move)
    seen = set()
    words = []
    for (r, c, _, _) in move.placed:
        for dr, dc in ((0, 1), (1, 0)):
            rr, cc = r, c
            while rr - dr >= 0 and cc - dc >= 0 and nb.grid[rr - dr][cc - dc]:
                rr -= dr
                cc -= dc
            key = (rr, cc, dr, dc)
            if key in seen:
                continue
            seen.add(key)
            chars = []
            while rr < N and cc < N and nb.grid[rr][cc]:
                chars.append(nb.grid[rr][cc])
                rr += dr
                cc += dc
            if len(chars) >= 2:
                words.append(''.join(chars))
    return words


def validate_move(board: Board, move: Move, lex: Lexicon) -> bool:
    return all(w in lex.words for w in words_formed(board, move))
