#!/usr/bin/env python3
"""Find the best Crossplay moves for a rack on a given board.

Examples:
    python3 solve.py --rack "EEB?JIH"
    python3 solve.py --rack "OSHEART" --board boards/mygame.txt --top 15
    python3 solve.py --rack "QI" --exclude blacklist.txt

Board file: 15 lines of 15 characters. '.' = empty, A-Z = tile,
lowercase a-z = a blank tile playing that letter. Rack: up to 7 characters,
'?' for each blank.
"""

import argparse
import sys
import time
from pathlib import Path

from crossplay import Board, Lexicon, generate_moves, validate_move, N


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--rack', required=True, help="e.g. EEB?JIH ('?' = blank)")
    ap.add_argument('--board', default=None, help='board file (default: empty board)')
    ap.add_argument('--dict', default='words/enable1.txt', dest='dict_path')
    ap.add_argument('--exclude', default='blacklist.txt',
                    help='optional file of words the app has rejected')
    ap.add_argument('--include', default='extras.txt',
                    help='optional file of valid words missing from the dictionary')
    ap.add_argument('--top', type=int, default=10)
    args = ap.parse_args()

    t0 = time.time()
    lex = Lexicon.load(args.dict_path, exclude_path=args.exclude,
                       include_path=args.include)
    board = Board.from_file(args.board) if args.board else Board.from_text(
        '\n'.join('.' * N for _ in range(N)))

    moves = generate_moves(board, args.rack, lex)
    dt = time.time() - t0

    if not moves:
        print('No legal moves found. Consider swapping tiles or passing.')
        return

    bad = [m for m in moves[:args.top] if not validate_move(board, m, lex)]
    if bad:
        print('WARNING: generator produced an invalid move, please report:',
              bad[0].describe(), file=sys.stderr)

    print(f'{len(moves)} legal moves found in {dt:.1f}s '
          f'({len(lex.words)} dictionary words). Top {min(args.top, len(moves))}:\n')
    print(f'{"#":>3}  {"PTS":>4}  {"POS":<5} {"DIR":<7} WORD')
    for i, m in enumerate(moves[:args.top], 1):
        arrow = 'across' if m.direction == 'H' else 'down'
        print(f'{i:>3}  {m.score:>4}  {m.notation():<5} {arrow:<7} {m.word}')

    best = moves[0]
    print('\nBest play on the board (new tiles in brackets, '
          'lowercase = blank):\n')
    highlight = {(r, c) for (r, c, _, _) in best.placed}
    print(board.place(best).render(highlight=highlight))


if __name__ == '__main__':
    main()
